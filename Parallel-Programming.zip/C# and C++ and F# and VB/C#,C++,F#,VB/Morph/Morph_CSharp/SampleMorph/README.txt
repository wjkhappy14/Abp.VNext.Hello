These images came from the Microsoft Office Online Clip Art gallery:
http://office.microsoft.com/en-US/clipart/results.aspx?qu=j0443592
http://office.microsoft.com/en-US/clipart/results.aspx?qu=j0443360