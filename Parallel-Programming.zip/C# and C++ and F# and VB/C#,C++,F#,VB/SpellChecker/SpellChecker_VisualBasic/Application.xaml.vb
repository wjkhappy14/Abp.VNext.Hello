﻿'--------------------------------------------------------------------------
' 
'  Copyright (c) Microsoft Corporation.  All rights reserved. 
' 
'  File: App.xaml.vb
'
'--------------------------------------------------------------------------


Namespace SpellChecker
	Partial Public Class App
		Inherits Application
	End Class
End Namespace
