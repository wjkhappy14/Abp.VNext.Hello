﻿//--------------------------------------------------------------------------
// 
//  Copyright (c) Microsoft Corporation.  All rights reserved. 
// 
//  File: App.xaml.cs
//
//--------------------------------------------------------------------------

using System.Windows;

namespace SpellChecker
{
    public partial class App : Application
    {
    }
}
