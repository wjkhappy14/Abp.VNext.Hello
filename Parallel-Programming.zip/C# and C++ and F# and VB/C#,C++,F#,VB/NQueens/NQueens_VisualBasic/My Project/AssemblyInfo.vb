﻿'--------------------------------------------------------------------------
' 
'  Copyright (c) Microsoft Corporation.  All rights reserved. 
' 
'  File: AssemblyInfo.cs
'
'--------------------------------------------------------------------------

Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

<Assembly: AssemblyTitle("NQueens_VisualBasic")> 
<Assembly: AssemblyDescription("")> 
<Assembly: AssemblyCompany("Microsoft Corporation")> 
<Assembly: AssemblyProduct("NQueens_VisualBasic")> 
<Assembly: AssemblyCopyright("Copyright © Microsoft Corporation.  All rights reserved.")> 
<Assembly: AssemblyTrademark("")> 
<Assembly: ComVisible(False)> 
<Assembly: Guid("33880c17-a42e-48ff-8932-fa991c1b1b54")> 
<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 