'--------------------------------------------------------------------------
' 
'  Copyright (c) Microsoft Corporation.  All rights reserved. 
' 
'  File: AssemblyInfo.vb
' 
'--------------------------------------------------------------------------

Imports System.Reflection
Imports System.Runtime.InteropServices

<Assembly: AssemblyTitle("Sudoku")>
<Assembly: AssemblyDescription("")>
<Assembly: AssemblyConfiguration("")>
<Assembly: AssemblyCompany("Microsoft Corporation")>
<Assembly: AssemblyProduct("Sudoku")>
<Assembly: AssemblyCopyright("Copyright � Microsoft Corporation. All Rights Reserved.")>
<Assembly: AssemblyTrademark("")>
<Assembly: AssemblyCulture("")>
<Assembly: ComVisible(False)>
<Assembly: CLSCompliant(False)>
<Assembly: Guid("c2b4f894-ceda-4768-b323-654faeaea994")>
<Assembly: AssemblyVersion("2.0.0.0")>
<Assembly: AssemblyFileVersion("2.0.0.0")>