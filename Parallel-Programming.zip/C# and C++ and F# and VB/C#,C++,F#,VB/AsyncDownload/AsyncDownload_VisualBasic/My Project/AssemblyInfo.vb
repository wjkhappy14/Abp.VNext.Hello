﻿'--------------------------------------------------------------------------
' 
'  Copyright (c) Microsoft Corporation.  All rights reserved. 
' 
'  File: AssemblyInfo.vb
'
'--------------------------------------------------------------------------

Imports System.Reflection
Imports System.Runtime.InteropServices

<Assembly: AssemblyTitle("AsyncDownload")> 
<Assembly: AssemblyDescription("")> 
<Assembly: AssemblyCompany("Microsoft")> 
<Assembly: AssemblyProduct("AsyncDownload")> 
<Assembly: AssemblyCopyright("Copyright © Microsoft Corporation.  All rights reserved.")> 
<Assembly: AssemblyTrademark("")> 
<Assembly: ComVisible(False)> 
<Assembly: Guid("ec68f6aa-f56a-4818-a6ff-0bd4e36eaf88")> 
<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 
